from django.db import models
class Exam(models.Model):
    subject = models.ForeignKey('Subject.Subject', on_delete=models.CASCADE)
    name = models.CharField(max_length=150)
    date = models.DateField()
    total_marks = models.PositiveIntegerField(default=100)
    def __str__(self): return f'{self.name} - {self.subject}'
