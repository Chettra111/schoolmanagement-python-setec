from django.test import TestCase

# Add Teacher tests here.
