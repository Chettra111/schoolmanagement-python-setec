from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from .forms import TeacherForm
from .models import Teacher


def teacher_list(request):
    query = request.GET.get('q', '').strip()
    teachers = Teacher.objects.all()

    if query:
        teachers = teachers.filter(
            Q(teacher_id__icontains=query)
            | Q(first_name__icontains=query)
            | Q(last_name__icontains=query)
            | Q(specialization__icontains=query)
            | Q(email__icontains=query)
        )

    return render(
        request,
        'teacher/teacher_list.html',
        {'teachers': teachers, 'query': query},
    )


def teacher_create(request):
    form = TeacherForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('teacher:list')

    return render(
        request,
        'teacher/teacher_form.html',
        {'form': form, 'page_title': 'Add Teacher', 'button_text': 'Save Teacher'},
    )


def teacher_detail(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    return render(request, 'teacher/teacher_detail.html', {'teacher': teacher})


def teacher_update(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    form = TeacherForm(request.POST or None, instance=teacher)

    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('teacher:list')

    return render(
        request,
        'teacher/teacher_form.html',
        {
            'form': form,
            'teacher': teacher,
            'page_title': 'Edit Teacher',
            'button_text': 'Update Teacher',
        },
    )


def teacher_delete(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)

    if request.method == 'POST':
        teacher.delete()
        return redirect('teacher:list')

    return render(
        request,
        'teacher/teacher_confirm_delete.html',
        {'teacher': teacher},
    )
