from django.db import models
class Subject(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=150)
    credit = models.PositiveSmallIntegerField(default=3)
    def __str__(self): return f'{self.code} - {self.name}'
