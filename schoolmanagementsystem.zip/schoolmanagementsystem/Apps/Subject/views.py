from django.shortcuts import render

def index(request):
    return render(request, 'core/module_placeholder.html', {'module_title': 'Subject Management', 'module_name': 'Subject'})
