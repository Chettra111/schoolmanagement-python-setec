from django.db import models
class Payment(models.Model):
    student = models.ForeignKey('Student.Student', on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    due_date = models.DateField()
    status = models.CharField(max_length=15, choices=[('PENDING','Pending'),('PAID','Paid'),('OVERDUE','Overdue')], default='PENDING')
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return f'{self.student} - {self.amount}'
