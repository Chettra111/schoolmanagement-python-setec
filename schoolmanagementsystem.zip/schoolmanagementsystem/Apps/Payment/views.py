from django.shortcuts import render

def index(request):
    return render(request, 'core/module_placeholder.html', {'module_title': 'Payment Management', 'module_name': 'Payment'})
