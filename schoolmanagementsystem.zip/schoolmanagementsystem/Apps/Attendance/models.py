from django.db import models
class Attendance(models.Model):
    student = models.ForeignKey('Student.Student', on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(max_length=15, choices=[('PRESENT','Present'),('ABSENT','Absent'),('LATE','Late')], default='PRESENT')
    class Meta:
        unique_together = ('student','date')
    def __str__(self): return f'{self.student} - {self.date}'
