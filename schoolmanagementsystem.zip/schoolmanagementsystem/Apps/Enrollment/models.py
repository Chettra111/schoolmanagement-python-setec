from django.db import models
class Enrollment(models.Model):
    student = models.ForeignKey('Student.Student', on_delete=models.CASCADE)
    subject = models.ForeignKey('Subject.Subject', on_delete=models.CASCADE)
    enrolled_at = models.DateField(auto_now_add=True)
    class Meta:
        unique_together = ('student','subject')
    def __str__(self): return f'{self.student} / {self.subject}'
