def site_context(request):
    return {'SITE_NAME': 'School Management System'}
