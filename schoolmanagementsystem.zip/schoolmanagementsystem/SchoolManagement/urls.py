from django.contrib import admin
from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('Core.urls')),
    path('students/', include('Apps.Student.urls')),
    path('teachers/', include('Apps.Teacher.urls')),
    path('subjects/', include('Apps.Subject.urls')),
    path('enrollment/', include('Apps.Enrollment.urls')),
    path('attendance/', include('Apps.Attendance.urls')),
    path('examinations/', include('Apps.Examination.urls')),
    path('payments/', include('Apps.Payment.urls')),
    path('reports/', include('Apps.Report.urls')),
    path('users/', include('Apps.UserManagement.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
