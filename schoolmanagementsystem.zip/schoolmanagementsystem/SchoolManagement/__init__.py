import pymysql

# Let Django's MySQL backend use PyMySQL.
pymysql.install_as_MySQLdb()
